package com.example.notepad

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ShelfActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shelf)
    }
}
